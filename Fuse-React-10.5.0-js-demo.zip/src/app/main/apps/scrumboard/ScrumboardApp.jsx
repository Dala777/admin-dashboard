import { Outlet } from 'react-router-dom';

/**
 * The scrumboard app.
 */
function ScrumboardApp() {
	return <Outlet />;
}

export default ScrumboardApp;

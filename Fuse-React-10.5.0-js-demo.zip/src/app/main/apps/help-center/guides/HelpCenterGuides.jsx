import { Outlet } from 'react-router-dom';

/**
 * The help center guides.
 */
function HelpCenterGuides() {
	return <Outlet />;
}

export default HelpCenterGuides;
